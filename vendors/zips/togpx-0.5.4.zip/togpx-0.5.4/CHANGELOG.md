0.5.3
-----
* fix ordering of metadata block in output

0.5.2
-----
* add callback option to get coordinate times of a feature by @JarnoLeConte

0.5.0
-----
* support for timestamps by @perliedman

0.4.0
-----
* output elevation in GPX if GeoJSON has altitude data (#5)

0.3.1
-----
* fix typo in package.json resulting that the CLI tool binary to be falsely called "topgx" instead of "togpx"

0.3.0
-----
* complete GeoJSON support (implements missing MultiPoint, MultiLineString, GeometryCollection, simple Features and simple Geometries)

0.2.0
-----
* documentation
* improve defaule description builder
* some code outsourcing, refactoring, browserifying

0.1.1
-----
* more tests
* various minor improvements

0.1.0
-----
* initial release
