
npm install grunt-contrib-uglify --save-dev
npm install grunt-contrib-concat --save-dev
npm install grunt-contrib-clean --save-dev
npm install grunt-contrib-cssmin --save-dev
npm install grunt-contrib-jshint --save-dev
npm install grunt-contrib-less --save-dev
npm install grunt-contrib-jasmine --save-dev
npm install grunt-contrib-connect --save-dev
npm install grunt-svg2png --save-dev
npm install jasmine --save-dev
